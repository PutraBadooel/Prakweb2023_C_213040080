/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// Nama : Moch. Nizar Al Fattan
// NPM : 213040078

/**
 *
 * @author NIZAR
 */
public class Main extends JFrame{
    private JTextField namaField; // untuk nama teman
    private JTextField nomorTeleponField; // untuk nomer telepon teman 
    private JTextArea biodataArea; // untuk menampilkan biodata teman

    public Main() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Aplikasi Biodata Teman"); // judul aplikasi
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // menutup aplikasi saat tombol close di klik
        setLayout(new FlowLayout()); // Menggunakan layout Flowlayout

        JLabel namaLabel = new JLabel("Nama:"); // label untuk input nama
        namaField = new JTextField(20); // untuk input nama dengan lebar 20 
        JLabel nomorTeleponLabel = new JLabel("Nomor Telepon:"); // label untuk input nomer telepon
        nomorTeleponField = new JTextField(20); // untuk input nomer telepon dengan lebar 20

        JButton simpanButton = new JButton("Simpan"); // tombol simpan untuk menyimpan biodata
        simpanButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                simpanBiodata(); // memanggil method simpan biodata() saat tombol simpan di kilk 
            }
        });

        biodataArea = new JTextArea(10, 40); // untuk menampilkan biodata dengan ukuran 10baris x 40 kolom
        biodataArea.setEditable(false); // agar tidak dapat di edeit oleh pengguna

        add(namaLabel); // menambahkan lebel "Nama:" ke frame
        add(namaField); // menambahkan JTextField untuk input nama ke frame
        add(nomorTeleponLabel); // menambahkan label "Nomor Telepon:" ke frame 
        add(nomorTeleponField); // menambahkan JTexField untuk input nomer telepon ke frame 
        add(simpanButton); // menambahkan lebel "Simpan" ke frame
        add(biodataArea); // menambahkan JTextArea untuk menampilkan biodata ke frame 

        pack(); // untuk mengatur ukuran frame sesuai dengan komponennya
        setLocationRelativeTo(null); // untuk menempatkan frame berada di tengah layar 
    }

    private void simpanBiodata() {
        String nama = namaField.getText();
        String nomorTelepon = nomorTeleponField.getText();

        if (!nama.isEmpty() && !nomorTelepon.isEmpty()) { // memeriksa apakah nama dan nomer telepon tidak kosong
            String biodata = "Nama: " + nama + "\nNomor Telepon: " + nomorTelepon + "\n"; // membentuk biodata dalam format yang di inginkan 
            biodataArea.append(biodata); //

            // Clear input fields
            namaField.setText("");
            nomorTeleponField.setText("");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Main().setVisible(true); // membuat objek main dan menampilkannya 
            }
        });
    }
}
